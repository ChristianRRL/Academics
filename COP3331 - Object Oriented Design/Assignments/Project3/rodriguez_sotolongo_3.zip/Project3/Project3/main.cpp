//file: main.cpp
//author(s): Christian Rodriguez & Gabriel Sotolongo

#include <iostream>
#include <cstdlib>
#include <vector>
#include "aHistogram.h"
#include "aDie.h"
using namespace std;


int inputValidation(void);		//integer input validation function

int main()
{
	aDie dieO1;							//die object 1
	aDie dieO2;							//die object 2
	aHistogram dieHistogram;		//a die histogram of the game
	int seed;								//seed for random number generator
	int rolls = 10000;					//number of rolls
	int const win = 1;					//constant 1 represents wins
	int const loss = 0;					//constant 0 represents losses
	int index=0;							//index used in loops
	int sum=0;								//sum of number1 & number2
	int point=0;							//if not win or loss, then point=sum
	int number1=0;						//number1 of die roll
	int number2=0;						//number2 of die roll
	int totalWin=0;						//total wins
	int totalLoss=0;						//total losses
	double odds=0;						//odds of winning (totalWin/rolls)

	while(1)
	{
	cout << "Enter a valid seed. Enter a negative number to exit the program! ";
	seed=inputValidation();
	
	if(seed < 0)
	{
		break;
	}


	srand(seed);

	dieHistogram.setRange(loss, win);

	cout << "Enter the number of simulations: ";
	rolls=inputValidation();
	cout << "This die will be rolled " << rolls << " times." << endl << endl;
	
	for (index=0; index<rolls; ++index)
	{
		if(index<5)//starting a game
		{
			cout << "GAME " << (index+1) << " STARTED." << endl;
		}
		number1=dieO1.roll();//rolling die 1 first time
		number2=dieO2.roll();//rolling die 2 first time
		sum=number1+number2;
		if(sum==7 || sum==11)//automatic win: sum equals 7 or 11
		{
			if(index<5)
			{
				cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum << ". You WIN!" << endl;
			}
			dieHistogram.update(win);
		}
		else if(sum==2 || sum==3 || sum==12)//automatic loss: sum equals 2 or 3 or 12
		{
			if(index<5)
			{
				cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum << ". You LOSE!" << endl;
			}
			dieHistogram.update(loss);
		}
		else//neither win nor loss on the first try
		{
			point=sum;
			if(index<5)
			{
				cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum << ". The point is " << point << ". Roll again" << endl;
			}
			while(1)//reroll
			{
				number1=dieO1.roll();//rerolling die 1
				number2=dieO2.roll();//rerolling die 2
				sum=number1+number2;
				if(sum==point)//win: sum equals point
				{
					if(index<5)
					{
						cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum << ". You WIN!" << endl;
					}
					dieHistogram.update(win);
					break;
				}
				else if(sum==7)//loss: sum equals 7
				{
					if(index<5)
					{
						cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum << ". You LOSE!" << endl;
					}
					dieHistogram.update(loss);
					break;
				}
				else//neither win nor loss
				{
					if(index<5)
					{
						cout << "You rolled " << number1 << " and " << number2 << " for a total of " << sum <<  ". Roll again" << endl;
					}
				}
			}
		}
		if(index<5)//ending a game
		{
			cout << "GAME " << (index+1) << " OVER." << endl << endl;
		}
	}
	totalWin = dieHistogram.count(win);
	totalLoss = dieHistogram.count(loss);
	cout << "OVERALL STATISTICS:" << endl;
	cout << "Total games played " << rolls << endl;
	cout << "Total games won: " << totalWin << endl;
	cout << "Total games lost: " << totalLoss << endl;
	cout << endl;

	dieHistogram.display();

	cout << endl;

	odds=(double)totalWin/(double)rolls;
	cout << "Odds of winning: " << odds*100 << "%" << endl;
	if(odds > 0.500)//odds greater than 50 percent
	{
		cout << "Conclusion: Play this game." << endl;
	}
	else//odds lower than 50 percent
	{
		cout << "Conclusion: Do no play this game." << endl;
	}

	dieHistogram.clear();
	cout << endl;
	}

	cout << "Thank you, come again!" << endl;
	system("pause");

	return 0;
}

int inputValidation(void)		//integer input validation function (only integer numbers valid)
{
	int integer;
	int extra=0;
	char ch;
	while(1)
	{
		cin >> integer;

		while((ch=getchar()) != '\n' && ch != EOF)
		{
			extra++;
		}
		if(extra==0)
		{
			cout << endl;
			break;
		}
		else
		{
			cout << "Incorrect Input. Try Again: ";
		}
		extra=0;
		cin.clear();
	}

	return integer;
}
