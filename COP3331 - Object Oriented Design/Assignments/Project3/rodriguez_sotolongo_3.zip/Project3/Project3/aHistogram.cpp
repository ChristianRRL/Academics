//file(s): aHistogram.cpp & aHistogram.h
//author(s): Christian Rodriguez & Gabriel Sotolongo

#include <iostream>
#include <cstdlib>
#include <vector>
#include "aHistogram.h"
#include "aDie.h"
using namespace std;


aHistogram::aHistogram(void)		//constructor
{
	this->setRange(0,1);
}


aHistogram::~aHistogram(void)		//destructor
{
}

void aHistogram::setRange(int low, int high)		//set the range of the histogram
{
	this->low=0;		//Loss
	this->high=1;		//Win
	size=(high - low) + 1;

	binVector.resize(size);

	return;
}

void aHistogram::update(int number)		//update the bin in histogram
{
	binVector.at(number)++;

	return;
}

int aHistogram::count(int randomNumber) const		//count the bin in histogram
{
	return binVector.at(randomNumber);
}

void aHistogram::display()		//display histogram
{
	int temp=0;
	double scale=0.0;
	for(int i=low; i<=high; i++)
	{
		if(count(i) > temp)
		{
			temp=count(i);
		}
	}

	scale=10/(double)temp;		//scale of histogram out of 10

	for(int i=high; i>=low; i--)
	{
		if((high - low) == 1)
		{
			if(i == high)
			{
				cout << "Won:   ";
			}
			if(i == low)
			{
				cout << "Lost:  ";
			}
		}
		else
		{
			cout << i << ":  ";
		}

		for(int j=0; j<count(i)*scale; j++)
		{
			cout << "x";
		}
		cout << " " << "(" << count(i) << ")" << endl;
	}

	cout << "The scale we are using is: " << scale << endl;

	return;
}

void aHistogram::clear()		//clear histogram
{
	binVector.clear();
}
