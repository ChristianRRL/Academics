// Compilation Instructions
In order to properly compile this code there are two commands that I used:

g++ -Wall main.cpp magicSquare.cpp -o main
./main

Additionally, for references, I used my previous C++ book (C++ How to Program), my Data Structures book (ADTs Data Structures and Problem Solving with C++), and http://www.cplusplus.com/.
