References:

C++ How to Program
-Chapter 6: Functions and an Introduction to Recursion (p.194)
-Chapter 14: Templates (p.595)
   ->Section 14.4

ADTs Data Structures and Problem Solving with C++

http://en.wikipedia.org/wiki/Permutation