#include "User.h"
#include <stdio.h>
#include <string.h>

int main()
{

	User me;

	me=create_user(25,6.1,185,"Ivan","Shindev","shindev@mail.usf.edu");

	if(me.valid)
	{
		show_user_info(me);
	}
	else
	{
		printf("User is not valid\n");
		return -1;
	}	
	

	return 0;
}
