#ifndef _UserH_
#define _UserH_

typedef struct 
{
	int age;
	double height;
	double weight;
	char first_name[100];
	char last_name[100];
	char email[100];
	int valid;
}User;

int verify_user_data(int _age,double _height,double _weight,char _first_name[],char _last_name[],char _email[]);

User create_user(int _age,double _height,double _weight,char _first_name[],char _last_name[],char _email[]);

void show_user_info(User _user);


#endif
