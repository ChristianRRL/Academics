#include "User.h"
#include <stdio.h>
#include <string.h>

int main()
{

	User users[2];
	
	users[0]=create_user(25,6.1,185,"Ivan","Shindev","shindev@mail.usf.edu");
	users[1]=create_user(250,6.1,185,"Ivan","Shindev","shindev@mail.usf.edu");

	if(users[0].valid)
	{
		show_user_info(users[0]);
	}
	if(users[1].valid)
	{
		show_user_info(users[1]);
	}	
	

	return 0;
}
