#include <stdio.h>

int main()
{
    int number_of_students = 0;
    printf ("Enter number of students in class: ");
    scanf ("%d", &number_of_students);
    printf ("The class has %d students\n", number_of_students);
    return 0;
}
